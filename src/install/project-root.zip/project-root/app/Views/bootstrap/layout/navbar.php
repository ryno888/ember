<?php
\Kwerqy\Ember\com\ui\ui::make()->ci_view((empty($controller) ?: $controller), function($buffer, $controller, $view){

    $url_arr = [];
    $url_arr[] = ["label" => "Home", "link" => \Kwerqy\Ember\com\http\http::build_action_url("website/index/home")];
    $url_arr[] = ["label" => "Catalogues", "link" => \Kwerqy\Ember\com\http\http::build_action_url("website/index/catalogue")];
    $url_arr[] = ["label" => "About", "link" => \Kwerqy\Ember\com\http\http::build_action_url("website/index/about")];
    $url_arr[] = ["label" => "Contact Us", "link" => \Kwerqy\Ember\com\http\http::build_action_url("website/index/contact")];
    $url_arr[] = ["label" => "Patriot Apparel", "link" => "https://patriotapparel.co.za/", "@target" => "_blank"];

    $is_home_page = \Kwerqy\Ember\com\http\http::get_control() != "website/index/home";

    $buffer->_section();
		$buffer->nav_([".shift d-none d-lg-block" => true, ".bg-warning" => $is_home_page]);
			$buffer->div_([".d-flex" => true]);
                $buffer->div_();
                    $buffer->ul_([".mb-0" => true]);

                        $fn_link = function($item)use(&$buffer){
                            $buffer->li_();
                                $buffer->xlink($item["link"], $item["label"], $item);
                            $buffer->_li();
                        };
                        foreach ($url_arr as $item) $fn_link($item);

                    $buffer->_ul();
                $buffer->_div();

                $buffer->div_([".d-flex align-items-center ms-auto px-4" => true]);
                    $buffer->xlink(getenv("ember.website.social.facebook"), false, ["icon" => "fab-facebook", ".navbar-social-link me-2" => true, "@target" => "_blank"]);
                    $buffer->xlink(getenv("ember.website.social.twitter"), false, ["icon" => "fab-twitter", ".navbar-social-link me-2" => true, "@target" => "_blank"]);
                    $buffer->xlink(getenv("ember.website.social.instagram"), false, ["icon" => "fab-instagram", ".navbar-social-link me-2" => true, "@target" => "_blank"]);
                    $buffer->xlink(getenv("ember.website.social.tiktok"), false, ["icon" => "fab-tiktok", ".navbar-social-link me-2" => true, "@target" => "_blank"]);
                    $buffer->xlink(\Kwerqy\Ember\com\http\http::build_action_url("website/index/contact"), false, ["icon" => "fa-envelope", ".navbar-social-link me-2" => true]);
                $buffer->_div();

			$buffer->_div();
		$buffer->_nav();

        $buffer->nav_([".navbar navbar-light navbar-expand-lg d-lg-none" => true, ".bg-warning" => \Kwerqy\Ember\com\http\http::get_control() != "website/index/home"]);
            $buffer->div_([".container-fluid" => true, ]);
                $buffer->button_([".navbar-toggler ms-auto" => true, "@data-toggle" => "collapse", "@data-target" => "#navcol-1", ]);
                    $buffer->span([".sr-only" => true, "*" => "Toggle navigation"]);
                    $buffer->span([".navbar-toggler-icon" => true, ]);
                $buffer->_button();
                $buffer->div_(["@id" => "navcol-1", ".collapse navbar-collapse" => true, ]);
                    $buffer->ul_([".navbar-nav" => true, ]);
                        $fn_link = function($item)use(&$buffer){
                            $buffer->li_([".nav-item navitems" => true, ]);
                                $buffer->xlink($item["link"], $item["label"], $item);
                            $buffer->_li();
                        };
                        foreach ($url_arr as $item) $fn_link($item);
                    $buffer->_ul();
                $buffer->_div();
            $buffer->_div();
        $buffer->_nav();
	$buffer->_section();

});